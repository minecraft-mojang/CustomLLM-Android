plugins{id("com.android.application");id("org.jetbrains.kotlin.android")}
android{namespace="com.example.llmlab";compileSdk=34
 defaultConfig{applicationId="com.example.llmlab";minSdk=26;targetSdk=34;versionCode=1;versionName="1.0"}
 compileOptions{sourceCompatibility=JavaVersion.VERSION_17;targetCompatibility=JavaVersion.VERSION_17}
 kotlinOptions{jvmTarget="17"}}
dependencies{implementation("androidx.activity:activity-ktx:1.9.1");implementation("androidx.webkit:webkit:1.11.0")}
