package com.example.llmlab

import android.app.ActivityManager
import android.content.Context
import android.net.Uri
import android.os.Bundle
import android.util.Base64
import android.view.WindowManager
import android.webkit.*
import androidx.activity.ComponentActivity
import androidx.activity.result.contract.ActivityResultContracts
import androidx.webkit.WebViewAssetLoader
import java.io.File
import java.io.RandomAccessFile

class MainActivity : ComponentActivity() {
    private lateinit var web: WebView
    private var chooser: ValueCallback<Array<Uri>>? = null
    private val pick = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { r ->
        chooser?.onReceiveValue(WebChromeClient.FileChooserParams.parseResult(r.resultCode, r.data)); chooser = null
    }
    private val prefs by lazy { getSharedPreferences("llm", Context.MODE_PRIVATE) }

    inner class Bridge {
        // model -> filesDir (app data, survives); corpus -> cacheDir (regenerable); exports -> app external files
        private fun target(k: String): File = when {
            k == "model" -> File(filesDir, "model.bin")
            k == "corpus" -> File(cacheDir, "corpus.bin")
            k.startsWith("export:") -> File(getExternalFilesDir(null), "exports").apply { mkdirs() }
                .let { File(it, k.removePrefix("export:").replace(Regex("[^A-Za-z0-9._-]"), "_")) }
            else -> throw IllegalArgumentException("bad key")
        }
        @JavascriptInterface fun write(k: String, i: Int, b64: String, last: Boolean) {
            val f = target(k); val tmp = File(f.path + ".tmp"); if (i == 0) tmp.delete()
            tmp.appendBytes(Base64.decode(b64, Base64.NO_WRAP))
            if (last) { f.delete(); tmp.renameTo(f) }
        }
        @JavascriptInterface fun size(k: String): Long = target(k).let { if (it.exists()) it.length() else -1L }
        @JavascriptInterface fun read(k: String, off: Long, len: Int): String =
            RandomAccessFile(target(k), "r").use { r ->
                r.seek(off); val b = ByteArray(minOf(len.toLong(), r.length() - off).toInt()); r.readFully(b)
                Base64.encodeToString(b, Base64.NO_WRAP)
            }
        @JavascriptInterface fun memInfo(): String {
            val am = getSystemService(ActivityManager::class.java); val mi = ActivityManager.MemoryInfo(); am.getMemoryInfo(mi)
            return """{"total":${mi.totalMem},"avail":${mi.availMem},"heap":${am.largeMemoryClass}}"""
        }
        @JavascriptInterface fun getBudget(): Int = prefs.getInt("mb", 1024)
        @JavascriptInterface fun setBudget(mb: Int) { prefs.edit().putInt("mb", mb).apply() }
    }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        val loader = WebViewAssetLoader.Builder().addPathHandler("/assets/", WebViewAssetLoader.AssetsPathHandler(this)).build()
        web = WebView(this).also { setContentView(it) }
        web.settings.apply { javaScriptEnabled = true; domStorageEnabled = true; allowFileAccess = false }
        web.addJavascriptInterface(Bridge(), "Android")
        web.webViewClient = object : WebViewClient() {
            override fun shouldInterceptRequest(v: WebView, r: WebResourceRequest) = loader.shouldInterceptRequest(r.url)
        }
        web.webChromeClient = object : WebChromeClient() {
            override fun onShowFileChooser(w: WebView, cb: ValueCallback<Array<Uri>>, p: FileChooserParams): Boolean {
                chooser?.onReceiveValue(null); chooser = cb
                return try { pick.launch(p.createIntent()); true } catch (e: Exception) { chooser = null; false }
            }
        }
        web.loadUrl("https://appassets.androidplatform.net/assets/index.html")
    }

    override fun onPause() { super.onPause(); web.evaluateJavascript("window.onNativePause&&window.onNativePause()", null) }
}
